package com.;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.video.Video;
import org.opencv.videoio.VideoCapture;

import javax.swing.*;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

public class camera extends JFrame{
    //camera screen
    private JLabel cameraScreen;
    private JButton btnCapture;
    private VideoCapture capture;
    private Mat image;
    private boolean clicked=false;
    public  camera (){
        //design ui
        setLayout(null);
        cameraScreen=new JLabel();
        cameraScreen.setBounds(0,0,640,480);
        add(cameraScreen);
        btnCapture= new JButton("capture");
        btnCapture.setBounds(300,480,80,40);
        add(btnCapture);
        btnCapture.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clicked=true;
            }
        });
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                capture.release();
                image.release();
                System.exit(0);
            }
        });

        setSize(new Dimension(640,560));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    //creat camera
    public void startcamera() {
        capture = new VideoCapture(0);
        image = new Mat();
        byte[] imageData;
        ImageIcon icon;

        while (true) {
            //read image to matrix
            capture.read(image);
            //convert matrix to bytes
            final MatOfByte buf = new MatOfByte();
            Imgcodecs.imencode(".jpg", image, buf);
            imageData = buf.toArray();
            //add to JLabel
            icon = new ImageIcon(imageData);
            cameraScreen.setIcon(icon);
            //capture and save to file
            if (clicked) {
                //prompt for enter image name
                String name = JOptionPane.showInputDialog("enter image name");
                if (name == null) {
                    name = new SimpleDateFormat("dd-mm-yyyy-hh-mm-ss").format(new Date());
                }
                //write to file
                Imgcodecs.imwrite("images/" + name + ".jpg", image);

                clicked = false;
            }

        }
    }

    public static void main(String[]args){
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                camera camera= new camera();
                //start camera in thread
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        camera.startcamera();
                    }
                }).start();
            }
        });
    }


}